﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Collections;
using System.Text;
using System.Text.RegularExpressions;

namespace ConsoleApplication1
{
    class OPZ
    {
        string input;
        public OPZ(string s)
        {
            input = s;
        }

        public string POIZ()
        {
            string otvet="";
            // Получаем массив строк с отдельными элементами выражения
            Regex rx = new Regex(@"\(|\)|\+|\-|\*|\/|<=?|>=?|!=|=|&&|\|\||([a-zA-z][a-zA-z0-9_]*)|(\d+\.?\d*)");
            // разбиваем на токены
            MatchCollection mc = rx.Matches(input);

            Regex id = new Regex(@"[a-zA-z][a-zA-z0-9_]*"); // идентификаторы
            Regex num = new Regex(@"\d+\.?\d*"); // числа целые и дробные
            Regex skobki = new Regex(@"\(|\)"); // скобки
            string[] operators = { "(", ")", "*", "/", "+", "-", "<", ">", "<=", ">=", "==", "!=", "&&", "||" }; // операторы по приоритету
            Regex opers = new Regex(@"\(|\)|\+|\-|\*|\/|<=?|>=?|!=|=|&&|\|\|"); // операторы

            Stack stOper = new Stack();
            ArrayList expr = new ArrayList();
            foreach (Match m in mc)
            {
                Match m1;
                m1 = id.Match(m.Value);
                if (m1.Success) { expr.Add(m1.Value); continue; }
                m1 = num.Match(m.Value);
                if (m1.Success) { expr.Add(m1.Value); continue; }
                m1 = skobki.Match(m.Value);
                if (m1.Success)
                {
                    if (m1.Value == "(") { stOper.Push(m1.Value); continue; }
                    string op = stOper.Pop().ToString();
                    while (op != "(")
                    {
                        expr.Add(op);
                        op = stOper.Pop().ToString();
                    }
                    continue;
                }
                m1 = opers.Match(m.Value);
                if (m1.Success)
                {
                    try
                    {
                        while (Array.IndexOf(operators, m1.Value) > Array.IndexOf(operators, stOper.Peek()))
                        {
                            if (stOper.Peek().ToString() == "(") break;
                            expr.Add(stOper.Pop().ToString());
                        }
                    }
                    catch (System.Exception ex)
                    {
                        // стек пустой
                    }
                    stOper.Push(m1.Value);
                }
            }
            while (stOper.Count != 0)
            {
                expr.Add(stOper.Pop().ToString());
            }
            foreach (string s in expr)
                otvet += s;

            return otvet;
        }
    }
}
