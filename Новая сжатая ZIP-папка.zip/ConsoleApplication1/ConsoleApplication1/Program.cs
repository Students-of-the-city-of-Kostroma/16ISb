﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("VVEDITE STROKU");
            string s = Console.ReadLine();
            OPZ klock = new OPZ(s);
            s= klock.POIZ();
            Console.WriteLine(s);
            Console.ReadLine();
        }
    }
}
